# MuJoCo 接触约束理论

mujoco中在接触实例化阶段把单个接触变成系统求解中的一行约束方程，其中实现时分为3类分支：
- 无摩擦接触（frictionless），无论全局option设置为pyramidal还是elliptic，若设置dim=1，就只考虑法向接触，无摩擦
- 棱锥摩擦锥（pyramidal cone），若设置dim>1，且设置cone="pyramidal"，则为此情况
- 椭圆摩擦锥（elliptic cone），若设置dim>1，且设置cone="elliptic"，则为此情况


## 1) `condim` 的接触维度语义

可通过设置`condim`参数，决定接触可生成的力/力矩分量维度；不同摩擦锥下对应的约束变量维度如下：

- `condim=1`：仅法向（无摩擦）；`elliptic` 为 1 维，`pyramidal` 也为 1 维。即单侧法向约束。
- `condim=3`：法向 + 两个切向摩擦分量；`elliptic` 为 3 维，`pyramidal` 为 4 维。
- `condim=4`：在 `condim=3` 基础上增加绕法向的扭转摩擦；`elliptic` 为 4 维，`pyramidal` 为 6 维。
- `condim=6`：进一步增加两方向滚动摩擦，可抑制持续滚动；`elliptic` 为 6 维，`pyramidal` 为 10 维。
对于elliptic，提供的约束方程行数nc=condim；对于pyramidal，提供的约束方程行数nc=2*(condim-1)。
`condim` 不取 `2` 或 `5`，因为切向与滚动方向的摩擦按成对维度处理。

### 4) 摩擦锥：elliptic 与 pyramidal

设单接触维度为 n（即 condim），摩擦系数向量为 $\mu$。官方给出两种摩擦锥定义：

$$
\text{elliptic cone}:\quad
\mathcal{K}=\left\{f\in\mathbb{R}^n:\ f_1\ge0,\ f_1^2\ge\sum_{i=2}^n \frac{f_i^2}{\mu_{i-1}^2}\right\}
$$

$$
\text{pyramidal cone}:\quad
\mathcal{K}=\left\{f\in\mathbb{R}^{2(n-1)}:\ f\ge0\right\}
$$

### 5) 接触对结果

- MuJoCo 的碰撞检测阶段会为每个候选接触对生成一个 `mjContact` 记录，供后续约束构建与求解使用。
- `dist`：两几何体沿接触法向的有符号距离。`dist > 0` 表示分离，`dist = 0` 表示刚好接触，`dist < 0` 表示穿透。
- `pos`：接触点位置（世界坐标），通常位于两接触表面沿法向的中间位置；后续 Jacobian 与约束都以该点为参考。
- `frame`：接触坐标系（3x3 旋转基，按行存储到 `mjContact.frame`）。其第 1 轴是法向方向，后两轴张成切向平面。
- `geom1/geom2`：参与接触的几何体 id；法向约定为从 `geom1` 指向 `geom2`，这会影响接触力方向与 Jacobian 符号。

![接触对几何关系示意图](./屏幕截图%202026-04-09%20130454.png)

### 5) 接触中间量计算， 雅克比矩阵Jacobian、位置级约束违约C、速度级约束违约Cdot
![MuJoCo 官方接触坐标系与摩擦基向量示意图](./contact_frame.svg)

- 对单接触先构造 $S\in\mathbb{R}^{6\times n_v}$：将广义速度 $\dot q$ 映射为接触点的速度（表达在接触系下），平移块在上、转动块在下，$S=[S_p^\top,S_r^\top]^\top$,有${}^{\mathrm{c}}V_{\mathrm{rel}}=S\,\dot q$。
- 再由接触基矩阵 \(E\) 将接触力分量映射到空间力/力矩，接触 Jacobian 为：
  $$
  J_c=E^T S
  $$
- 该块 Jacobian 最终插入系统级 \(J\)（即 `efc_J`）参与整体求解。
- 位置级约束违约（记为 `C`），
  - frictionless：`C = dist`（1 行）；
  - pyramidal：每个棱边行都写 `C = dist`（每个摩擦维 2 行）；
  - elliptic：仅法向行写 `C = dist`，其余摩擦行不收嵌入深度影响，为C = 0。
- 速度级约束违约（记为 `Cdot`）由 Jacobian乘上广义速度直接得到。

### 6) 求解
在 求解的代价/状态评估中，
- `pyramidal`（以及 frictionless/limit）按“非负锥约束”处理：当 `jar >= 0` 时记为 `SATISFIED` 且该行约束力置 0；当 `jar < 0` 时进入 `QUADRATIC` 区并产生非零接触力。
- `elliptic` 接触按二阶锥分三段处理（top/bottom/middle zone）：。。。
